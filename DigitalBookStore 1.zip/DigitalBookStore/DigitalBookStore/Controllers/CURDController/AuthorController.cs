﻿using DigitalBookStore.Models;
using Microsoft.AspNetCore.Mvc;
using DigitalBookStore.DTO;
using DigitalBookStore.Repositories.Interface;

namespace DigitalBookStore.Controllers.CRUDControllers
{
    [Route("api/[controller/action]")]
    [ApiController]
    //[Authorize(Roles = "Admin")]
     

    public class AuthorController : ControllerBase
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }
        [HttpPost]
        public async Task<ActionResult<Author>> AddAuthorAsync([FromBody] AuthorDTO authordto)

        {
            if (authordto == null)
            {
                return BadRequest("Invalid Data");
            }

            await _authorRepository.AddAuthorAsync(authordto);
            return Ok(authordto);
        }
    }
}
