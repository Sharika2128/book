﻿using Microsoft.EntityFrameworkCore.Metadata;
using System.ComponentModel.DataAnnotations;

namespace DigitalBookStore.Models
{
    public class Author
    {
        [Key]
        public required int AuthorID { get; set; }
        public required string Name { get; set; }
        public ICollection<Book>? book { get; set; }
            
    }
}
