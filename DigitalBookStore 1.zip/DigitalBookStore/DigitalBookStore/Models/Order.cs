﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderID { get; set; }
        public required DateTime OrderDate { get; set; }
        public required double TotalAmount {get; set;}
        public required OrderStatus Status { get; set; }
        [ForeignKey(nameof(User))]
        public required int UserID { get; set; }
        public User? User { get; set; }

        public static implicit operator OrderStatus(Order v)
        {
            throw new NotImplementedException();
        }
    }
    public enum OrderStatus
    {
        Pending,
        Shipped,
        Delivered
    }
}
