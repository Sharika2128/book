﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class Review
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ReviewID { get; set; }
        public  int Rating { get; set; }
        public required string Comments { get; set; }
        [ForeignKey(nameof(User))]
        public required int UserID { get; set; }
        [ForeignKey(nameof(Book))]
        public required int BookID { get; set; }
        public User? User { get; set; }
        public Book? Book { get; set; }
        public string Comment { get; internal set; }
    }
}
