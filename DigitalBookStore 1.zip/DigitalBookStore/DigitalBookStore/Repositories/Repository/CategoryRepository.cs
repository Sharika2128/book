﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using DigitalBookStore.Repositories.Interface;

namespace DigitalBookstoreManagementSystem.Repositories.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly DigitalBookStoreDBContext _context;
        public CategoryRepository(DigitalBookStoreDBContext context)
        {
            _context = context;
        }
        public async Task AddCategoryAsync(CategoryDTO categorydto)
        {
            var category = new Category
            {
                CategoryID = 0,
                Name = categorydto.Name,
            };

            if (categorydto != null)
            {
                await _context.Categories.AddAsync(category);
                await _context.SaveChangesAsync();
            }
        }
    }
}


