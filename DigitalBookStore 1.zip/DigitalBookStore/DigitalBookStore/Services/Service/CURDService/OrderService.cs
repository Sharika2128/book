﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using DigitalBookStore.Services.Interface;
using DigitalBookstoreManagementSystem.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace DigitalBookstoreManagementSystem.Services.Service.CRUDService
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _orderRepository.GetOrders();
        }
        public async Task<Order?> GetOrderById(int id)
        {
            return await _orderRepository.GetOrderById(id);
        }
        public async Task<Order> CreateOrder(OrderDTO orderdto)
        {
            var order = GetOrder(orderdto);

            return await _orderRepository.CreateOrder(order);
        }

        private static Order GetOrder(OrderDTO orderdto)
        {
            return new Order { OrderID = orderdto.OrderID, OrderDate = orderdto.OrderDate, TotalAmount = orderdto.TotalAmount, Status = orderdto.Status, UserID = orderdto.UserID, };
        }

        public async Task<bool> UpdateOrderStatus(int id, OrderStatus status)
        {
            return await _orderRepository.UpdateOrderStatus(id, status);

        }
        public async Task<bool> DeleteOrder(int orderId)
        {
            return await _orderRepository.DeleteOrder(orderId);
        }
    }
}

